## Packages
recharts | For financial data visualization (charts)
framer-motion | For smooth page transitions and micro-interactions
date-fns | For date formatting and manipulation
react-day-picker | For date selection in forms
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Using Replit Auth for authentication (already setup).
Using Replit AI (OpenAI) for financial insights.
Using Shadcn UI components (already installed).
