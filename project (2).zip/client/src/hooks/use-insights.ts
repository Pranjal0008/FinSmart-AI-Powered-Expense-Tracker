import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useInsights() {
  return useQuery({
    queryKey: [api.insights.list.path],
    queryFn: async () => {
      const res = await fetch(api.insights.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch insights");
      return api.insights.list.responses[200].parse(await res.json());
    },
  });
}

export function useGenerateInsight() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.insights.generate.path, {
        method: api.insights.generate.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate insight");
      return api.insights.generate.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.insights.list.path] });
      toast({ title: "Insight Generated", description: "Your new financial analysis is ready." });
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to generate insight. Please try again later.", 
        variant: "destructive" 
      });
    },
  });
}
