import { Sidebar } from "@/components/Sidebar";
import { AIChatBot } from "@/components/AIChatBot";
import { useInsights, useGenerateInsight } from "@/hooks/use-insights";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2, Lightbulb } from "lucide-react";
import { format } from "date-fns";

export default function InsightsPage() {
  const { data: insights, isLoading } = useInsights();
  const generateMutation = useGenerateInsight();

  const handleGenerate = () => {
    generateMutation.mutate();
  };

  return (
    <div className="flex min-h-screen bg-background font-sans">
      <Sidebar />
      <main className="flex-1 md:ml-64 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight text-foreground">AI Insights</h1>
            <p className="text-muted-foreground mt-1">Get personalized financial advice powered by Artificial Intelligence.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Insights Feed */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center justify-between">
                 <h2 className="text-xl font-bold font-display">Analysis Reports</h2>
                 <Button 
                   onClick={handleGenerate} 
                   disabled={generateMutation.isPending}
                   className="shadow-lg shadow-primary/25"
                 >
                   {generateMutation.isPending ? (
                     <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                   ) : (
                     <Sparkles className="w-4 h-4 mr-2" />
                   )}
                   Generate New Report
                 </Button>
              </div>

              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2].map(i => (
                    <div key={i} className="h-40 bg-muted/50 rounded-2xl animate-pulse" />
                  ))}
                </div>
              ) : !insights || insights.length === 0 ? (
                <div className="p-12 text-center bg-card rounded-2xl border border-border border-dashed">
                  <Lightbulb className="w-12 h-12 mx-auto text-primary/20 mb-4" />
                  <p className="text-muted-foreground">No insights generated yet. Click the button above to analyze your finances.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {insights.map((insight) => (
                    <div key={insight.id} className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                           <div className="p-2 bg-primary/10 rounded-lg text-primary">
                             <Sparkles className="w-4 h-4" />
                           </div>
                           <h3 className="font-semibold">{insight.type.charAt(0).toUpperCase() + insight.type.slice(1)} Analysis</h3>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(insight.createdAt), "MMM d, yyyy h:mm a")}
                        </span>
                      </div>
                      <div className="prose prose-sm max-w-none text-muted-foreground">
                        <p>{insight.content}</p>
                      </div>
                      {insight.recommendation && (
                        <div className="mt-4 p-4 bg-success/10 rounded-xl border border-success/20">
                          <p className="text-sm font-medium text-success-foreground">
                            <span className="font-bold">Recommendation:</span> {insight.recommendation}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right Column - Chat Bot */}
            <div className="lg:col-span-1">
               <h2 className="text-xl font-bold font-display mb-6">Financial Advisor</h2>
               <div className="sticky top-8">
                 <AIChatBot />
               </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
