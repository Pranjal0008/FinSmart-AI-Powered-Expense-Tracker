import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  ArrowRight, 
  BarChart3, 
  ShieldCheck, 
  Sparkles 
} from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight">FinSmart</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/api/login">
              <Button>
                Sign In <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/5 border border-primary/10 text-primary text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            <span>Now powered by OpenAI GPT-4</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight mb-6 bg-gradient-to-r from-foreground to-foreground/60 bg-clip-text text-transparent">
            Master your money with AI intelligence.
          </h1>
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Track expenses, visualize your wealth, and get personalized financial advice from your own AI advisor.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="/api/login">
              <Button size="lg" className="h-12 px-8 text-base">
                Get Started Free
              </Button>
            </a>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base">
              View Demo
            </Button>
          </div>
        </div>
        
        {/* Hero Image / Dashboard Preview */}
        <div className="container mx-auto mt-20">
          <div className="relative rounded-2xl overflow-hidden border border-border shadow-2xl shadow-primary/10 aspect-video max-w-5xl mx-auto bg-card">
             {/* Abstract Dashboard Representation for Landing Page */}
             <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent flex items-center justify-center">
                <div className="text-center">
                   <p className="text-muted-foreground font-display text-lg">Dashboard Preview</p>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-card border border-border/50 hover:shadow-lg transition-all duration-300">
              <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center text-success mb-6">
                <BarChart3 className="w-6 h-6" />
              </div>
              <h3 className="font-display font-bold text-xl mb-3">Smart Tracking</h3>
              <p className="text-muted-foreground">
                Automatically categorize your expenses and visualize your spending habits with beautiful interactive charts.
              </p>
            </div>
            <div className="p-8 rounded-2xl bg-card border border-border/50 hover:shadow-lg transition-all duration-300">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="font-display font-bold text-xl mb-3">AI Advisor</h3>
              <p className="text-muted-foreground">
                Chat with our AI financial advisor to get personalized insights, savings tips, and budget recommendations.
              </p>
            </div>
            <div className="p-8 rounded-2xl bg-card border border-border/50 hover:shadow-lg transition-all duration-300">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-500 mb-6">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-display font-bold text-xl mb-3">Bank-Grade Security</h3>
              <p className="text-muted-foreground">
                Your financial data is encrypted and secure. We use industry-standard protocols to keep your information safe.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>&copy; 2024 FinSmart Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
