import { useStats } from "@/hooks/use-transactions";
import { ArrowDownRight, ArrowUpRight, Wallet, TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export function StatsCards() {
  const { data: stats, isLoading } = useStats();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 rounded-2xl w-full" />
        ))}
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {/* Total Balance */}
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 relative overflow-hidden group">
        <div className="absolute right-0 top-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
          <Wallet className="w-24 h-24" />
        </div>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <Wallet className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Net Balance</span>
        </div>
        <h3 className="text-3xl font-bold tracking-tight font-display">
          ${stats.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </h3>
        <p className="text-sm text-muted-foreground mt-2">Current available funds</p>
      </div>

      {/* Income */}
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 relative overflow-hidden group">
        <div className="absolute right-0 top-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
          <TrendingUp className="w-24 h-24 text-success" />
        </div>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center text-success">
            <ArrowUpRight className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Total Income</span>
        </div>
        <h3 className="text-3xl font-bold tracking-tight font-display text-success">
          +${stats.totalIncome.toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </h3>
        <p className="text-sm text-muted-foreground mt-2">All time earnings</p>
      </div>

      {/* Expenses */}
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 relative overflow-hidden group">
        <div className="absolute right-0 top-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
          <TrendingDown className="w-24 h-24 text-danger" />
        </div>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center text-danger">
            <ArrowDownRight className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Total Expenses</span>
        </div>
        <h3 className="text-3xl font-bold tracking-tight font-display text-danger">
          -${Math.abs(stats.totalExpenses).toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </h3>
        <p className="text-sm text-muted-foreground mt-2">All time spending</p>
      </div>
    </div>
  );
}
