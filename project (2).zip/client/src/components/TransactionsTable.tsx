import { useTransactions, useDeleteTransaction } from "@/hooks/use-transactions";
import { format } from "date-fns";
import { 
  MoreHorizontal, 
  Trash2, 
  Edit, 
  ArrowUpRight, 
  ArrowDownRight,
  Search,
  Filter
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { TransactionForm } from "./TransactionForm";
import { cn } from "@/lib/utils";

export function TransactionsTable({ limit }: { limit?: number }) {
  const { data: transactions, isLoading } = useTransactions();
  const deleteMutation = useDeleteTransaction();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  if (isLoading) {
    return <div className="p-8 text-center text-muted-foreground">Loading transactions...</div>;
  }

  if (!transactions) return null;

  let filtered = transactions.filter(t => 
    t.description.toLowerCase().includes(search.toLowerCase()) ||
    t.category.toLowerCase().includes(search.toLowerCase())
  );

  // Apply sorting by date descending
  filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (limit) {
    filtered = filtered.slice(0, limit);
  }

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this transaction?")) {
      await deleteMutation.mutateAsync(id);
    }
  };

  const editingTransaction = transactions.find(t => t.id === editingId);

  return (
    <div className="space-y-4">
      {!limit && (
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search transactions..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-card"
            />
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" />
            Filter
          </Button>
        </div>
      )}

      <div className="bg-card rounded-xl border border-border/50 shadow-sm overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-muted/50 border-b border-border/50">
            <tr>
              <th className="px-6 py-4 font-medium text-muted-foreground">Description</th>
              <th className="px-6 py-4 font-medium text-muted-foreground">Category</th>
              <th className="px-6 py-4 font-medium text-muted-foreground">Date</th>
              <th className="px-6 py-4 font-medium text-muted-foreground text-right">Amount</th>
              <th className="px-6 py-4 font-medium text-muted-foreground text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                  No transactions found.
                </td>
              </tr>
            ) : (
              filtered.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center",
                        transaction.type === "income" ? "bg-success/10 text-success" : "bg-danger/10 text-danger"
                      )}>
                        {transaction.type === "income" ? (
                          <ArrowUpRight className="w-4 h-4" />
                        ) : (
                          <ArrowDownRight className="w-4 h-4" />
                        )}
                      </div>
                      <span className="font-medium text-foreground">{transaction.description}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">
                    <span className="px-2 py-1 rounded-full bg-muted text-xs font-medium">
                      {transaction.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">
                    {format(new Date(transaction.date), "MMM d, yyyy")}
                  </td>
                  <td className={cn(
                    "px-6 py-4 text-right font-medium",
                    transaction.type === "income" ? "text-success" : "text-foreground"
                  )}>
                    {transaction.type === "income" ? "+" : "-"}${Number(transaction.amount).toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-muted">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingId(transaction.id)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-destructive focus:text-destructive"
                          onClick={() => handleDelete(transaction.id)}
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={!!editingId} onOpenChange={(open) => !open && setEditingId(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Transaction</DialogTitle>
          </DialogHeader>
          {editingTransaction && (
            <TransactionForm 
              initialData={editingTransaction} 
              onSuccess={() => setEditingId(null)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
