import { useStats } from "@/hooks/use-transactions";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = [
  'hsl(221, 83%, 53%)', // Primary Blue
  'hsl(142, 71%, 45%)', // Success Green
  'hsl(262, 83%, 58%)', // Purple
  'hsl(38, 92%, 50%)',  // Orange
  'hsl(0, 84%, 60%)',   // Red
  'hsl(200, 90%, 50%)', // Light Blue
];

export function FinancialChart() {
  const { data: stats, isLoading } = useStats();

  if (isLoading) {
    return <Skeleton className="h-[300px] w-full rounded-xl" />;
  }

  if (!stats) return null;

  // Transform data for pie chart
  const pieData = stats.categoryBreakdown.map((item) => ({
    name: item.category,
    value: Number(item.amount),
  }));

  // Mock data for bar chart since we only have aggregate stats currently
  // In a real app, we'd query monthly aggregates from the API
  const barData = [
    { name: 'Income', value: stats.totalIncome },
    { name: 'Expenses', value: stats.totalExpenses },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm">
        <h3 className="text-lg font-bold mb-6 font-display">Income vs Expenses</h3>
        <div className="h-[250px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E5E7EB" />
              <XAxis type="number" stroke="#6B7280" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis dataKey="name" type="category" stroke="#6B7280" fontSize={12} tickLine={false} axisLine={false} width={80} />
              <Tooltip 
                cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {barData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.name === 'Income' ? 'hsl(142, 71%, 45%)' : 'hsl(0, 84%, 60%)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm">
        <h3 className="text-lg font-bold mb-6 font-display">Spending by Category</h3>
        <div className="h-[250px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                 contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Legend iconType="circle" fontSize={12} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
