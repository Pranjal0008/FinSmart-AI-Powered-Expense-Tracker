import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { batchProcess } from "./replit_integrations/batch";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication
  await setupAuth(app);
  registerAuthRoutes(app);

  // Setup Chat (Financial Advisor)
  registerChatRoutes(app);

  // --- Finance API Routes ---

  // List Transactions
  app.get(api.transactions.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const transactions = await storage.getTransactions(userId);
    res.json(transactions);
  });

  // Get Transaction
  app.get(api.transactions.get.path, isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const transaction = await storage.getTransaction(id);
    if (!transaction) return res.status(404).json({ message: "Transaction not found" });
    
    // Check ownership
    const userId = (req.user as any).claims.sub;
    if (transaction.userId !== userId) return res.status(403).json({ message: "Forbidden" });

    res.json(transaction);
  });

  // Create Transaction
  app.post(api.transactions.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.transactions.create.input.parse(req.body);
      const userId = (req.user as any).claims.sub;
      const transaction = await storage.createTransaction(userId, input);
      res.status(201).json(transaction);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Update Transaction
  app.put(api.transactions.update.path, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const input = api.transactions.update.input.parse(req.body);
      const userId = (req.user as any).claims.sub;
      
      const existing = await storage.getTransaction(id);
      if (!existing) return res.status(404).json({ message: "Transaction not found" });
      if (existing.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const updated = await storage.updateTransaction(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Delete Transaction
  app.delete(api.transactions.delete.path, isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const userId = (req.user as any).claims.sub;

    const existing = await storage.getTransaction(id);
    if (!existing) return res.status(404).json({ message: "Transaction not found" });
    if (existing.userId !== userId) return res.status(403).json({ message: "Forbidden" });

    await storage.deleteTransaction(id);
    res.status(204).send();
  });

  // Get Stats
  app.get(api.stats.get.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const transactions = await storage.getTransactions(userId);
    
    let totalIncome = 0;
    let totalExpenses = 0;
    const categoryMap: Record<string, number> = {};

    transactions.forEach(t => {
      const amount = Number(t.amount);
      if (t.type === 'income') {
        totalIncome += amount;
      } else {
        totalExpenses += amount;
        categoryMap[t.category] = (categoryMap[t.category] || 0) + amount;
      }
    });

    const categoryBreakdown = Object.entries(categoryMap).map(([category, amount]) => ({
      category,
      amount,
      percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0
    })).sort((a, b) => b.amount - a.amount);

    res.json({
      totalIncome,
      totalExpenses,
      balance: totalIncome - totalExpenses,
      categoryBreakdown
    });
  });

  // List Insights
  app.get(api.insights.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const insights = await storage.getInsights(userId);
    res.json(insights);
  });

  // Generate Insight (AI)
  app.post(api.insights.generate.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const transactions = await storage.getTransactions(userId);
    
    // Prepare data for AI
    const summary = {
      totalIncome: 0,
      totalExpenses: 0,
      categories: {} as Record<string, number>,
      recentTransactions: transactions.slice(0, 10).map(t => ({
        date: t.date,
        type: t.type,
        category: t.category,
        amount: t.amount,
        description: t.description
      }))
    };

    transactions.forEach(t => {
      const amount = Number(t.amount);
      if (t.type === 'income') {
        summary.totalIncome += amount;
      } else {
        summary.totalExpenses += amount;
        summary.categories[t.category] = (summary.categories[t.category] || 0) + amount;
      }
    });

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a helpful financial advisor. Analyze the provided financial data and provide 3-4 concise, actionable insights and savings recommendations. Format your response as a simple list of insights." },
          { role: "user", content: `Here is my financial summary: ${JSON.stringify(summary)}` }
        ],
      });

      const insightText = response.choices[0]?.message?.content || "No insights generated.";
      
      const insight = await storage.createInsight(userId, {
        userId,
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear(),
        insightText
      });

      res.status(201).json(insight);
    } catch (error) {
      console.error("AI Insight Error:", error);
      res.status(500).json({ message: "Failed to generate insights" });
    }
  });

  return httpServer;
}
